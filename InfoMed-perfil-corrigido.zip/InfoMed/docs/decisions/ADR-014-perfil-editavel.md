# ADR-014: Edição dos dados do perfil

- **Status:** Aceita
- **Contexto:** A tela Perfil continha dados pessoais fictícios fixos e botões sem ações. As telas não devem acessar o banco diretamente.
- **Decisão:** Criar `ProfileRepository`, com implementações Mock e Supabase, e manter a tela dependente apenas desse contrato. Os campos persistidos são nome, data de nascimento e telefone, existentes na tabela `profiles`. O e-mail continua gerenciado pelo Supabase Auth e não é editável nesta tela.
- **Alternativas consideradas:** manter os dados estáticos; consultar o Supabase diretamente no componente; guardar dados pessoais apenas em estado local.
- **Consequências:** a tela permite editar e persistir os campos suportados tanto no modo Mock quanto no Supabase. O endereço não é exibido como se fosse real porque ainda não existe coluna de endereço no esquema atual.
- **Segurança:** atualização filtrada pelo ID do usuário autenticado e protegida pela política RLS existente em `profiles`.
- **Como validar:** abrir Perfil, clicar em Editar, alterar nome/telefone/data de nascimento, salvar e recarregar a tela.
