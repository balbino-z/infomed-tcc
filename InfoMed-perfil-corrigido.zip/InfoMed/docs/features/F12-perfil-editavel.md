# Feature: Perfil editável

- **Requisito atendido (RF/RNF):** permitir que a pessoa visualize e atualize seus dados pessoais sem acessar informações de outros usuários.
- **Disciplina relacionada:** Projeto Integrador II, Segurança e Defesa Cibernética.
- **Padrão ou tecnologia usada e por quê:** Repository, para manter a tela desacoplada do Supabase e suportar Mock nos testes.
- **Arquivos principais:** `src/app/components/screens/Profile.tsx`, `src/app/domain/profile.ts`, `src/app/repositories/ProfileRepository.ts`, `src/app/repositories/mock/MockProfileRepository.ts`, `src/app/repositories/supabase/SupabaseProfileRepository.ts`.
- **Como testar:** entrar, abrir Perfil, editar nome, telefone e data de nascimento, salvar e atualizar a página. O e-mail é somente leitura.
- **Evidência (print ou diagrama):** pendente de captura no navegador.
- **Observações / dificuldades encontradas:** o endereço que aparecia anteriormente era fictício e foi removido. O esquema atual não tem campo de endereço. As contagens de consultas e lembretes agora são carregadas dos repositórios, em vez de números fixos.
