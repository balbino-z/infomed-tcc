import { useEffect, useState, type FormEvent } from 'react';
import { User, Mail, Phone, Calendar, Bell, Lock, HelpCircle, LogOut, ChevronRight, Pencil, X } from 'lucide-react';
import type { Screen } from '../../App';
import type { UserProfile } from '../../domain/profile';
import { useAuth } from '../../features/auth/AuthContext';
import { appointmentRepository, profileRepository, reminderRepository } from '../../repositories';
import { Header } from '../shared/Header';
import { BottomNav } from '../shared/BottomNav';

interface ProfileProps {
  navigate: (screen: Screen, data?: any) => void;
}

type InfoPanel = 'privacy' | 'help' | null;

const inputClass = 'mt-1 w-full rounded-xl border border-[#D9E6F7] bg-white px-4 py-3 text-[#1A2B48] outline-none focus:border-[#0A73FF] focus:ring-2 focus:ring-[#0A73FF]/10';

export function Profile({ navigate }: ProfileProps) {
  const { user, signOut } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [phone, setPhone] = useState('');
  const [appointmentCount, setAppointmentCount] = useState<number | null>(null);
  const [reminderCount, setReminderCount] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [panel, setPanel] = useState<InfoPanel>(null);

  useEffect(() => {
    if (!user) return;
    let active = true;
    Promise.all([
      profileRepository.getMine(user.id),
      appointmentRepository.listMine(),
      reminderRepository.list(),
    ]).then(([savedProfile, appointments, reminders]) => {
      if (!active) return;
      setProfile(savedProfile);
      setFullName(savedProfile.fullName || user.fullName || '');
      setBirthDate(savedProfile.birthDate);
      setPhone(savedProfile.phone);
      setAppointmentCount(appointments.filter((item) => item.status === 'agendada').length);
      setReminderCount(reminders.filter((item) => item.active).length);
    }).catch((e: unknown) => {
      if (!active) return;
      setError(e instanceof Error ? e.message : 'Não foi possível carregar os dados do perfil.');
      setFullName(user.fullName || '');
    }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [user]);

  const beginEditing = () => {
    setFullName(profile?.fullName || user?.fullName || '');
    setBirthDate(profile?.birthDate || '');
    setPhone(profile?.phone || '');
    setError('');
    setSuccess('');
    setEditing(true);
  };

  const saveProfile = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!user) return;
    if (fullName.trim().length < 3) {
      setError('Informe seu nome completo (pelo menos 3 caracteres).');
      return;
    }
    setError('');
    setSuccess('');
    setSaving(true);
    try {
      const updated = await profileRepository.updateMine(user.id, { fullName, birthDate, phone });
      setProfile(updated);
      setFullName(updated.fullName);
      setBirthDate(updated.birthDate);
      setPhone(updated.phone);
      setEditing(false);
      setSuccess('Seus dados foram atualizados.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Não foi possível salvar os dados.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="h-full bg-[#F7FAFF] flex flex-col">
      <Header title="Perfil" showNotification={false} />

      <div className="flex-1 overflow-y-auto px-6 py-6 pb-24">
        <div className="mb-6 rounded-3xl bg-gradient-to-br from-[#0A73FF] to-[#005BEA] p-6 text-white">
          <div className="mb-6 flex items-center gap-4">
            <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-white/20 text-3xl">👤</div>
            <div className="min-w-0 flex-1">
              <h2 className="mb-1 break-words text-lg font-semibold">{profile?.fullName || user?.fullName || 'Usuário'}</h2>
              <p className="break-all text-sm text-white/80">{user?.email || 'E-mail não disponível'}</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-2xl bg-white/10 p-3">
              <p className="mb-1 text-xs text-white/70">Consultas agendadas</p>
              <p className="text-xl">{appointmentCount === null ? '—' : appointmentCount}</p>
            </div>
            <div className="rounded-2xl bg-white/10 p-3">
              <p className="mb-1 text-xs text-white/70">Lembretes ativos</p>
              <p className="text-xl">{reminderCount === null ? '—' : reminderCount}</p>
            </div>
          </div>
        </div>

        {error && !editing && <p role="alert" className="mb-4 rounded-xl bg-[#FF4D5E]/10 p-3 text-sm text-[#C6283A]">{error}</p>}
        {success && <p role="status" className="mb-4 rounded-xl bg-[#27C183]/10 p-3 text-sm text-[#16784B]">{success}</p>}

        <section className="mb-4 rounded-2xl border border-[#E8F1FF] bg-white p-6">
          <div className="mb-4 flex items-center justify-between gap-3">
            <h3 className="font-semibold text-[#1A2B48]">Informações Pessoais</h3>
            {!editing && (
              <button onClick={beginEditing} className="flex items-center gap-1 text-sm font-medium text-[#0A73FF]" aria-label="Editar informações pessoais">
                <Pencil className="h-4 w-4" /> Editar
              </button>
            )}
          </div>

          {editing ? (
            <form onSubmit={saveProfile} className="space-y-4">
              <label className="block text-sm text-[#64748B]">Nome completo
                <input className={inputClass} value={fullName} onChange={(e) => setFullName(e.target.value)} autoComplete="name" required minLength={3} maxLength={120} />
              </label>
              <label className="block text-sm text-[#64748B]">E-mail
                <input className={`${inputClass} bg-[#F7FAFF]`} value={user?.email ?? ''} readOnly aria-readonly="true" />
                <span className="mt-1 block text-xs">O e-mail de acesso não pode ser alterado nesta tela.</span>
              </label>
              <label className="block text-sm text-[#64748B]">Telefone
                <input className={inputClass} type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} autoComplete="tel" placeholder="(19) 99999-9999" maxLength={25} />
              </label>
              <label className="block text-sm text-[#64748B]">Data de nascimento
                <input className={inputClass} type="date" value={birthDate} onChange={(e) => setBirthDate(e.target.value)} max={new Date().toISOString().slice(0, 10)} />
              </label>
              {error && <p role="alert" className="text-sm text-[#C6283A]">{error}</p>}
              <div className="flex gap-3 pt-1">
                <button type="button" onClick={() => { setEditing(false); setError(''); }} className="flex-1 rounded-xl border border-[#D9E6F7] px-4 py-3 text-[#64748B]" disabled={saving}>Cancelar</button>
                <button type="submit" className="flex-1 rounded-xl bg-[#0A73FF] px-4 py-3 font-medium text-white disabled:opacity-60" disabled={saving || loading}>{saving ? 'Salvando...' : 'Salvar alterações'}</button>
              </div>
            </form>
          ) : (
            <div className="space-y-4">
              <InfoRow icon={<Mail className="mt-0.5 h-5 w-5" />} label="E-mail" value={user?.email || 'Não informado'} />
              <InfoRow icon={<Phone className="mt-0.5 h-5 w-5" />} label="Telefone" value={profile?.phone || 'Não informado'} />
              <InfoRow icon={<Calendar className="mt-0.5 h-5 w-5" />} label="Data de nascimento" value={formatBirthDate(profile?.birthDate)} />
              {loading && <p className="text-sm text-[#64748B]">Carregando dados...</p>}
            </div>
          )}
        </section>

        <section className="mb-4 overflow-hidden rounded-2xl border border-[#E8F1FF] bg-white">
          <MenuButton icon={<Bell />} label="Notificações" color="#FFCC48" onClick={() => navigate('notifications')} />
          <MenuButton icon={<Lock />} label="Privacidade e Segurança" color="#FF4D5E" onClick={() => setPanel('privacy')} />
          <MenuButton icon={<HelpCircle />} label="Ajuda e Suporte" color="#27C183" onClick={() => setPanel('help')} last />
        </section>

        <div className="mb-4 flex items-center justify-between rounded-2xl border border-[#E8F1FF] bg-white p-4">
          <span className="text-sm text-[#64748B]">Versão do app</span>
          <span className="text-sm text-[#1A2B48]">1.0.0</span>
        </div>

        <button onClick={async () => { await signOut(); navigate('login'); }} className="flex h-[52px] w-full items-center justify-center gap-2 rounded-2xl bg-[#FF4D5E]/10 text-[#FF4D5E] transition-colors hover:bg-[#FF4D5E]/20">
          <LogOut className="h-5 w-5" /> Sair da Conta
        </button>
      </div>

      {panel && (
        <div className="fixed inset-0 z-[100] flex items-end justify-center bg-black/40 p-4 sm:items-center" role="presentation" onClick={() => setPanel(null)}>
          <section role="dialog" aria-modal="true" aria-labelledby="profile-panel-title" className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <h2 id="profile-panel-title" className="font-semibold text-[#1A2B48]">{panel === 'privacy' ? 'Privacidade e Segurança' : 'Ajuda e Suporte'}</h2>
              <button aria-label="Fechar" onClick={() => setPanel(null)} className="rounded-full p-2 hover:bg-[#F7FAFF]"><X className="h-5 w-5" /></button>
            </div>
            {panel === 'privacy' ? (
              <div className="space-y-3 text-sm leading-6 text-[#64748B]">
                <p>O InfoMed usa autenticação para proteger sua conta e restringe o acesso aos seus dados pessoais ao próprio usuário.</p>
                <p>Seus dados de perfil são armazenados no Supabase e protegidos por políticas de segurança por usuário (RLS).</p>
                <p>Recuperação de senha, exclusão da conta e exportação dos dados ainda não estão disponíveis nesta versão.</p>
              </div>
            ) : (
              <div className="space-y-3 text-sm leading-6 text-[#64748B]">
                <p>Use o menu inferior para acessar início, medicamentos, postos, histórico e perfil.</p>
                <p>O InfoMed é um projeto informativo e não substitui avaliação ou orientação de um profissional de saúde.</p>
                <p>Se encontrar um problema, registre a tela e a descrição para reportar à equipe do projeto.</p>
              </div>
            )}
            <button onClick={() => setPanel(null)} className="mt-5 w-full rounded-xl bg-[#0A73FF] px-4 py-3 font-medium text-white">Entendi</button>
          </section>
        </div>
      )}
      <BottomNav active="profile" onNavigate={navigate} />
    </div>
  );
}

function InfoRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3 text-[#64748B]">
      {icon}
      <div className="min-w-0 flex-1">
        <p className="text-sm">{label}</p>
        <p className="break-words text-[#1A2B48]">{value}</p>
      </div>
    </div>
  );
}

function MenuButton({ icon, label, color, onClick, last = false }: { icon: React.ReactNode; label: string; color: string; onClick: () => void; last?: boolean }) {
  return (
    <button onClick={onClick} className={`flex w-full items-center gap-4 p-4 text-left transition-colors hover:bg-[#F7FAFF] ${last ? '' : 'border-b border-[#E8F1FF]'}`}>
      <span className="flex h-10 w-10 items-center justify-center rounded-xl" style={{ backgroundColor: `${color}15`, color }}>{icon}</span>
      <span className="flex-1 text-[#1A2B48]">{label}</span>
      <ChevronRight className="h-5 w-5 text-[#CED6E0]" />
    </button>
  );
}

function formatBirthDate(value?: string): string {
  if (!value) return 'Não informado';
  const parts = value.split('-');
  return parts.length === 3 ? `${parts[2]}/${parts[1]}/${parts[0]}` : value;
}
