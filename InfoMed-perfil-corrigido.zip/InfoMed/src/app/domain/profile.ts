export interface UserProfile {
  id: string;
  fullName: string;
  birthDate: string;
  phone: string;
}

export type UpdateProfileInput = Pick<UserProfile, 'fullName' | 'birthDate' | 'phone'>;
