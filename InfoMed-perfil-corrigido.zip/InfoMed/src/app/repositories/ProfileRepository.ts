import type { UpdateProfileInput, UserProfile } from '../domain/profile';

export interface ProfileRepository {
  getMine(userId: string): Promise<UserProfile>;
  updateMine(userId: string, input: UpdateProfileInput): Promise<UserProfile>;
}
