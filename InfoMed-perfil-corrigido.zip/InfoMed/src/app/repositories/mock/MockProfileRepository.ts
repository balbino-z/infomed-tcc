import type { UpdateProfileInput, UserProfile } from '../../domain/profile';
import type { ProfileRepository } from '../ProfileRepository';

const keyFor = (userId: string) => `infomed.mock.profile.${userId}`;

export class MockProfileRepository implements ProfileRepository {
  async getMine(userId: string): Promise<UserProfile> {
    try {
      const raw = localStorage.getItem(keyFor(userId));
      if (raw) return JSON.parse(raw) as UserProfile;
    } catch {
      // Se o armazenamento estiver indisponível, retorna os dados básicos.
    }
    let fullName = '';
    try {
      const session = localStorage.getItem('infomed.mock.session');
      if (session) fullName = (JSON.parse(session) as { fullName?: string }).fullName ?? '';
    } catch {
      // Mantém nome vazio.
    }
    return { id: userId, fullName, birthDate: '', phone: '' };
  }

  async updateMine(userId: string, input: UpdateProfileInput): Promise<UserProfile> {
    const profile: UserProfile = {
      id: userId,
      fullName: input.fullName.trim(),
      birthDate: input.birthDate,
      phone: input.phone.trim(),
    };
    try {
      localStorage.setItem(keyFor(userId), JSON.stringify(profile));
      const session = localStorage.getItem('infomed.mock.session');
      if (session) {
        const user = JSON.parse(session) as { id: string; email: string; fullName: string };
        if (user.id === userId) localStorage.setItem('infomed.mock.session', JSON.stringify({ ...user, fullName: profile.fullName }));
      }
    } catch {
      throw new Error('Não foi possível salvar os dados neste navegador.');
    }
    return profile;
  }
}
