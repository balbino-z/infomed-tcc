import type { SupabaseClient } from '@supabase/supabase-js';
import type { UpdateProfileInput, UserProfile } from '../../domain/profile';
import type { ProfileRepository } from '../ProfileRepository';

type ProfileRow = {
  id: string;
  full_name: string | null;
  birth_date: string | null;
  phone: string | null;
};

function toProfile(row: ProfileRow): UserProfile {
  return {
    id: row.id,
    fullName: row.full_name ?? '',
    birthDate: row.birth_date ?? '',
    phone: row.phone ?? '',
  };
}

export class SupabaseProfileRepository implements ProfileRepository {
  constructor(private readonly db: SupabaseClient) {}

  async getMine(userId: string): Promise<UserProfile> {
    const { data, error } = await this.db
      .from('profiles')
      .select('id, full_name, birth_date, phone')
      .eq('id', userId)
      .single();
    if (error || !data) throw new Error('Não foi possível carregar seus dados pessoais.');
    return toProfile(data as ProfileRow);
  }

  async updateMine(userId: string, input: UpdateProfileInput): Promise<UserProfile> {
    const { data, error } = await this.db
      .from('profiles')
      .update({
        full_name: input.fullName.trim(),
        birth_date: input.birthDate || null,
        phone: input.phone.trim() || null,
      })
      .eq('id', userId)
      .select('id, full_name, birth_date, phone')
      .single();
    if (error || !data) throw new Error('Não foi possível salvar seus dados. Tente novamente.');
    // Mantém o nome exibido na sessão alinhado ao perfil.
    await this.db.auth.updateUser({ data: { full_name: input.fullName.trim() } });
    return toProfile(data as ProfileRow);
  }
}
