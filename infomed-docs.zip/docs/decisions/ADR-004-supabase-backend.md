# ADR-004: Supabase como backend e banco de dados na nuvem

- **Status:** Aceita (a implementar)
- **Data:** 20/10/2026
- **Disciplinas relacionadas:** Computação em Nuvem, Segurança e Defesa Cibernética, Business Intelligence e Big Data

## Contexto

O aplicativo precisa de autenticação de usuários, armazenamento de dados de saúde (consultas, lembretes), consulta a medicamentos e postos, e notificações. Há um único desenvolvedor e um prazo de aproximadamente um mês, portanto escrever e hospedar uma API própria é inviável. Por tratar dados de saúde, a proteção por usuário e a conformidade com a LGPD são requisitos centrais.

## Decisão

Utilizar o **Supabase** como plataforma de backend na nuvem, com:

- **PostgreSQL** como banco de dados relacional;
- **Supabase Auth** para cadastro e login;
- **Row Level Security (RLS)**, com políticas do tipo `user_id = auth.uid()` nas tabelas de dados pessoais (consultas, lembretes, notificações, perfil);
- **Edge Functions** para lógica de servidor, como a futura funcionalidade de IA, mantendo chaves de API fora do navegador;
- **Views SQL** como fonte de dados para o dashboard de BI.

Modelo de dados inicial: `profiles`, `medications`, `health_units`, `unit_medications`, `specialties`, `doctors`, `appointments`, `reminders`, `notifications`.

## Alternativas consideradas

| Alternativa | Por que não foi escolhida |
|---|---|
| Firebase | Banco NoSQL, menos adequado a relações entre consultas, médicos e unidades; consultas para BI são mais difíceis |
| API própria (Node ou Java) com banco hospedado | Muito trabalho para o prazo e mais superfície de ataque a proteger |
| Backend fictício (JSON local) | Não cumpre os requisitos de nuvem e segurança |

## Consequências

**Positivas**
- Banco relacional, autenticação e segurança por linha prontos, com camada gratuita suficiente para o TCC.
- RLS fornece evidência concreta para o capítulo de segurança.
- SQL padrão facilita a integração com ferramentas de BI.

**Negativas / riscos**
- Dependência de fornecedor externo (mitigada pelo padrão Repository, ver ADR-003).
- Limites da camada gratuita.
- Políticas de RLS mal escritas podem expor dados, então precisam ser testadas e documentadas.

## Evidências

- Script SQL do esquema e das políticas
- Print do painel do Supabase com as políticas de RLS
- Teste demonstrando que um usuário não acessa dados de outro
