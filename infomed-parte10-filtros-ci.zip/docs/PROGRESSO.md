# Diário de progresso

> Uma entrada por sessão de trabalho, **a mais recente no final**. Quem começa a sessão lê as últimas entradas; quem termina escreve a sua.
> Peça ao Claude: "resuma o que fizemos no formato do PROGRESSO.md".

## Modelo de entrada

```
### Sessão N — AAAA-MM-DD — <nome de quem trabalhou>
**Tarefa:** (ex.: T3 unidades reais)
**Feito:**
- ...
**Arquivos criados/alterados:** ...
**SQL novo para rodar no Supabase:** (nenhum | db/0X_nome.sql — já rodado? sim/não)
**Testes:** tsc ok? npm test ok? build ok?
**Pendências / bloqueios:** ...
**Próximo passo sugerido:** ...
**Docs atualizados:** ADR-0XX / F0X / evidências
```

---

### Sessão 1 — 20/10/2026 — dono do repositório
**Tarefa:** Sprint 0 (base do projeto)
**Feito:**
- Planejamento: mapa matéria → entrega, escopo P0/P1/P2, cronograma de 4 semanas, stack decidida.
- Análise do export do Figma Make (20 telas) e levantamento de problemas (ADR-002).
- Ambiente: Node, Git e VS Code; projeto movido para `C:\projetos\InfoMed`.
- `package.json` reescrito (sem entradas `pacote@versão` e sem dependências não usadas); script `fix-imports.mjs` removeu versões dos imports em 41 arquivos.
- Repositório no GitHub (privado) e primeiro commit.
**Testes:** build ok; app rodando em `localhost:5173`.

### Sessão 2 — 20/10/2026 — dono do repositório
**Tarefa:** Camada de domínio e padrão Repository
**Feito:**
- `tsconfig.json`, `vite-env.d.ts`; erros de tipo zerados (inclusive correção do tipo de `navigate` em `MedicationDetail`).
- `domain/medication.ts`, `MedicationRepository`, `MockMedicationRepository`; `MedicationList` passou a usar o repositório.
- ADRs 001, 002, 003, 005, 006 e ficha F01.
**Testes:** tsc ok; busca "met" mostra só a Metformina.

### Sessão 3 — 20/10/2026 — dono do repositório
**Tarefa:** Supabase (banco e RLS)
**Feito:**
- Projeto Supabase (São Paulo); `db/01_schema.sql` (9 tabelas, RLS, GRANT, gatilho de perfil, `booked_slots`, view `medications_with_status`), `db/02_seed.sql`, `db/03_teste_rls.sql`.
- `lib/supabase.ts`, `SupabaseMedicationRepository`, `repositories/index.ts` escolhendo Mock/Supabase pelo `.env`; `.env.example`.
- ADR-004 e ADR-007; `diagrams/modelo-er.md`; `security/testes-rls.md`; fichas F02 e F03.
**SQL rodado no Supabase:** 01 e 02 (confirmado).
**Testes:** tela de Medicamentos lendo do banco (confirmado).
**Observação:** o esquema também foi validado em um PostgreSQL local com `auth` simulado (isolamento entre usuários ok); falta repetir no Supabase real com 2 contas.

### Sessão 4 — 20/10/2026 — dono do repositório
**Tarefa:** Autenticação e LGPD
**Feito (código entregue):**
- `domain/user.ts`, `AuthRepository`, `SupabaseAuthRepository`, `MockAuthRepository`, `AuthContext`.
- Telas `Login` e `Signup` (aceite LGPD obrigatório, senha mínima de 8); telas internas bloqueadas sem login; Home e Perfil mostram o nome do usuário; botão "Sair da Conta".
- `db/04_auth.sql` (gatilho grava `lgpd_consent_at`); Vitest 3 com 4 testes; ADR-008, ficha F04, `diagrams/fluxo-autenticacao.md`.
**SQL novo para rodar no Supabase:** `db/04_auth.sql` — **confirmar se já foi rodado**.
**Testes:** tsc ok, 4 testes ok, build ok (verificados fora do ambiente do usuário).
**Pendências:** testar cadastro/login no navegador com o Supabase real; desativar "Confirm email" no painel para a demonstração; teste de RLS com 2 contas; prints em `docs/evidence`.
**Próximo passo sugerido:** T1, T2 e depois T3 (unidades reais de Santa Bárbara d'Oeste).

### Sessão 5 — 20/10/2026 — dono do repositório
**Tarefa:** PWA e publicação na Vercel (antecipada em relação à fila)
**Feito (código entregue):**
- `vite-plugin-pwa` com manifesto (nome, cores, ícones, `standalone`) e service worker com atualização automática; só a interface é guardada em cache, dados do Supabase sempre pela rede.
- Ícones do app (192, 512, maskable, apple-touch, favicon) em `public/`; `index.html` com metadados de tema e iOS.
- `App.tsx`: moldura de iPhone só em telas largas (`md+`); no celular o app ocupa a tela toda (`100dvh`). Isso resolve a parte da moldura da T6; **react-router continua pendente**.
- ADR-009 (PWA e Vercel) e ficha F05.
**Testes:** tsc ok, 4 testes ok, build ok (manifesto e service worker gerados).
**Pendências:** instalar `vite-plugin-pwa` (`npm install -D vite-plugin-pwa`), publicar na Vercel com as variáveis do `.env`, ajustar URL no Supabase (Authentication → URL Configuration), testar a instalação no celular, prints em `docs/evidence`.
**Atenção:** a Vercel (plano gratuito) bloqueia deploys de commits de outras contas em repositório privado. Decidir: repositório público, só o dono comita na `main`, ou outra hospedagem.
**Próximo passo sugerido:** T3 (unidades reais de Santa Bárbara d'Oeste).

### Sessão 6 — 20/10/2026 — dono do repositório
**Tarefa:** T3 (unidades reais de Santa Bárbara d'Oeste) — levantamento e ferramentas
**Feito:**
- PWA publicado na Vercel (corrigido: `node_modules` tinha ido para o Git; removido e `.gitignore` ajustado).
- Levantamento nas fontes oficiais da Prefeitura: 15 UBS (nome, endereço, telefone, horário, serviços) em `data/unidades-sbo.json`.
- UBS Vista Alegre excluída (fechada desde 2020, segundo reportagem de 2026); UBS Regional Zona Sul incluída.
- Scripts: `scripts/geocode-unidades.mjs` (coordenadas via OpenStreetMap) e `scripts/gerar-sql-unidades.mjs` (gera `db/05_postos_reais.sql`).
- Documentação das fontes, divergências e dados simulados em `docs/data/fontes-unidades.md`.
**SQL novo para rodar no Supabase:** `db/05_postos_reais.sql` — **ainda não gerado**; depende de rodar o geocoder e conferir os pontos. Apaga unidades, estoque, médicos e consultas de teste antigos.
**Testes:** gerador e SQL validados em PostgreSQL local (com coordenadas de teste); geocoder validado com respostas simuladas.
**Pendências:** rodar o geocoder na máquina do dev, conferir os 15 pontos no mapa, resolver as 4 divergências de endereço (ver docs/data/fontes-unidades.md), gerar e rodar o SQL.
**Próximo passo sugerido:** T4 (`HealthUnitRepository` e telas de Postos lendo do banco).

### Sessão 7 — 20/10/2026 — dono do repositório
**Tarefa:** T1, T2, T3 concluídas pelo dono; T4 e T5 (postos lendo do banco e mapa) entregues em código
**Feito:**
- T1 (login e cadastro no ambiente real), T2 (teste de isolamento RLS) e T3 (`db/05_postos_reais.sql` rodado com as UBS reais) confirmados pelo dono. Corrigido o nome das variáveis de ambiente (`VITE_...`, não `NEXT_PUBLIC_...`) e desativado "Confirm email" no Supabase para a demonstração.
- T4: `HealthUnit`, `HealthUnitRepository` (Mock e Supabase), telas `PostosList` e `PostoDetail` lendo do banco (aberto/fechado, serviços, telefone, medicamentos da unidade com estoque simulado).
- T5: mapa com Leaflet e OpenStreetMap carregado sob demanda; marcadores verdes e cinzas; botão "Perto de mim" (ordena por distância, localização só no aparelho); "Como chegar" abre a rota.
- `unitUtils.ts` (horário em fuso de São Paulo, Haversine) com testes; ADR-005 atualizado; ficha F06.
**SQL novo para rodar no Supabase:** nenhum.
**Testes:** tsc ok, 11 testes ok, build ok (mapa em pacote separado de ~156 kB). Nenhuma verificação visual do mapa foi feita fora do ambiente do dono.
**Pendências:** testar visualmente lista, mapa e detalhe (no PC e no celular); prints em `docs/evidence`; conferir as 4 unidades com endereço divergente; `npm install leaflet@1.9.4 react-leaflet@4.2.1` e `npm i -D @types/leaflet` se ainda não instalados.
**Próximo passo sugerido:** T6 (react-router), depois T7 (agendamento).

### Sessão 8 — 20/10/2026 — dono do repositório
**Tarefa:** T6 (navegação por rotas) e correção dos testes
**Feito:**
- Testes corrigidos: `vitest.config.ts` agora força os repositórios Mock mesmo com `.env` presente (antes, 3 testes falhavam na máquina do dev porque usavam o Supabase real).
- T4/T5 validados pelo dono no PC e no celular (postos reais, mapa, "Perto de mim").
- T6: react-router 7 com `BrowserRouter`; URLs em português (`/postos`, `/postos/:id`, `/medicamentos/:id`, `/agendar`, `/lembretes/novo`...); adaptador `useAppNavigate` mantém o contrato `navigate('tela', dados)` das telas; detalhes carregam por id da URL (link direto e F5 funcionam); proteção de rotas (sem login → `/entrar`; logado em `/` ou `/entrar` → `/inicio`); `Header` volta no histórico; `aria-label` em Voltar e Notificações; `vercel.json` com reescrita para SPA.
- ADR-010 e ficha F07; README e CONTEXTO atualizados.
**SQL novo para rodar no Supabase:** nenhum.
**Testes:** tsc ok, 19 testes ok, build ok (PWA com 18 arquivos em cache).
**Pendências:** testar no PC e no celular (botão voltar, link direto, F5, logout); prints em `docs/evidence`; os dados dos fluxos (especialidade, médico, data) ainda ficam só em memória até o agendamento (T7).
**Atenção para a dupla:** `App.tsx` mudou muito (agora só monta o router e o layout). Quem estiver com branch aberta deve fazer `git pull` antes de mexer em rotas.
**Próximo passo sugerido:** T7 (agendamento ponta a ponta, padrão Factory, função `booked_slots`).

### Sessão 9 — 20/10/2026 — dono do repositório
**Tarefa:** T7 (agendamento) e T8 (lembretes e notificações), entregues juntas
**Feito:**
- T6 validada pelo dono (voltar, link direto, F5 e login/logout funcionando).
- T7: `db/06_agendamento.sql` (gatilho de regras, índices únicos, notificações automáticas, view `my_appointments`); domínio `appointment.ts`; `AppointmentRepository` (Mock e Supabase); padrão **Factory** (`AppointmentFactory`, com regras por tipo); horários de 30 em 30 min com ocupados bloqueados; telas Especialidade, Médico, Data e Hora, Confirmação, Histórico e Cancelar reescritas; cartão "Próxima consulta" real na Home.
- T8: `db/07_lembretes.sql` (nome livre e validações); padrão **Observer** (`EventBus`); `ReminderRepository` e `NotificationRepository` (Mock e Supabase); `ReminderScheduler` + alerta "Hora do remédio"; telas Lembretes, Novo Lembrete e Notificações reescritas; contador no sino (Header e Home); lembretes de hoje na Home.
- ADR-011, ADR-012, fichas F08 e F09, `diagrams/padroes-de-projeto.md`, casos T9 a T27 em `security/testes-rls.md`.
**SQL novo para rodar no Supabase:** `db/06_agendamento.sql` e depois `db/07_lembretes.sql` (podem ser repetidos sem problema).
**Testes:** tsc ok, 37 testes ok (com e sem `.env`), build ok; as regras do banco foram validadas em PostgreSQL local (22 casos). Nada foi visto no navegador fora do ambiente do dono.
**Pendências:** rodar os dois SQL; testar o fluxo no PC e no celular com duas contas; prints e preencher a coluna "Resultado no Supabase" em `security/testes-rls.md`; avisos de lembrete só com o app aberto (limitação).
**Próximo passo sugerido:** T9 (filtros com padrão Strategy), T10 (CI GitHub Actions), T11 (IA), T12 (BI), T13 (pesquisa SUS). Sugestão de divisão: dev A = T9 + T10; dev B = T11 + T12; ambos = T13.

### Sessão 10 — 20/10/2026 — dono do repositório
**Tarefa:** T9 (filtros com Strategy) e T10 (CI com GitHub Actions)
**Feito:**
- T9: padrão **Strategy** (`features/units/filters/`): 4 filtros (aberto agora, distância, serviços, medicamento disponível) e 2 ordenações (nome, distância); tela `MapFilters` funcional (serviços vêm das unidades; medicamentos do catálogo); `PostosList` aplica os filtros, mostra contador e "N postos com os filtros escolhidos"; `unitIdsWithMedication` nos repositórios (Mock e Supabase); ADR-013, ficha F10 e diagrama.
- T10: `.github/workflows/ci.yml` com dois jobs (**App**: npm ci, typecheck, testes, build; **Database**: PostgreSQL 16 + substitutos do Supabase + scripts 01 a 07 + `db/ci/tests.sql`); testes de banco convertidos de manuais para automáticos e validados por mutação; scripts `typecheck` e `test`; `README.md` em inglês na raiz (cumpre a parte do README em inglês da Língua Inglesa II); ADR-006 atualizado; ficha F11.
**SQL novo para rodar no Supabase:** nenhum.
**Testes:** tsc ok, 50 testes ok, build ok; job App simulado em cópia limpa com `npm ci`; job Database simulado em PostgreSQL local (passa; com defeito injetado, falha); workflow validado com actionlint. O pipeline em si ainda não rodou no GitHub.
**Pendências:** aplicar `npm pkg set scripts.typecheck="tsc --noEmit"` (e conferir que `test` existe); confirmar que `package-lock.json` está no Git; dar `push` e conferir a aba Actions; print do pipeline verde; opcional: proteger a `main` exigindo os dois jobs.
**Próximo passo sugerido:** T11 (IA) e T12 (BI) pelo dono; T13 (pesquisa SUS) depois.

### Sessão 11 — (a preencher) — (nome)
