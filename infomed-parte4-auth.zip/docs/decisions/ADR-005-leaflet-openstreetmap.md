# ADR-005: Leaflet e OpenStreetMap para mapas

- **Status:** Aceita (a implementar)
- **Data:** 20/10/2026
- **Disciplinas relacionadas:** Programação Multi Plataforma, Sistemas de Informação e Tecnologias Emergentes

## Contexto

As telas de postos de saúde e de filtros no mapa precisam exibir a localização das unidades. O projeto não deve depender de cartão de crédito ou de chaves de API pagas.

## Decisão

Utilizar a biblioteca **Leaflet** (via `react-leaflet`) com mapas base do **OpenStreetMap**, e coordenadas (latitude e longitude) armazenadas na tabela `health_units`.

## Alternativas consideradas

| Alternativa | Por que não foi escolhida |
|---|---|
| Google Maps | Exige conta de faturamento e chave de API |
| Mapbox | Exige chave de API e tem limites de uso gratuito |
| Mapa estático (imagem) | Não permite interação nem filtros |

## Consequências

**Positivas**
- Gratuito e sem chave de API.
- Funciona bem em PWA e em dispositivos móveis.
- Dados abertos, coerentes com o tema de saúde pública.

**Negativas / riscos**
- Menos recursos prontos (rotas, trânsito) do que o Google Maps.
- É preciso respeitar a política de uso dos servidores de tiles do OpenStreetMap e incluir a atribuição exigida.

## Evidências

- Print da tela de detalhe do posto com o mapa
- Trecho de código do componente de mapa
