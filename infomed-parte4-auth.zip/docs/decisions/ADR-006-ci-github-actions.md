# ADR-006: Integração e entrega contínuas com GitHub Actions

- **Status:** Aceita (a implementar)
- **Data:** 20/10/2026
- **Disciplinas relacionadas:** Integração e Entrega Contínua

## Contexto

O código já é versionado no GitHub. Para garantir qualidade e demonstrar práticas de integração contínua, é necessário automatizar a verificação de cada alteração e a publicação do aplicativo.

## Decisão

Criar um fluxo de trabalho no **GitHub Actions** (`.github/workflows/ci.yml`) executado a cada `push` e `pull request` na branch `main`, com as etapas:

1. Instalação de dependências (`npm ci`);
2. Verificação de tipos (`tsc --noEmit`);
3. Testes automatizados com **Vitest**, usando o `MockRepository`;
4. Build de produção (`vite build`);
5. Deploy automático em hospedagem estática (por exemplo, Vercel) quando a branch `main` for atualizada.

```mermaid
flowchart LR
  A[push / pull request] --> B[npm ci]
  B --> C[tsc --noEmit]
  C --> D[vitest]
  D --> E[vite build]
  E --> F{branch main?}
  F -- sim --> G[Deploy]
  F -- não --> H[Fim]
```

## Alternativas consideradas

| Alternativa | Por que não foi escolhida |
|---|---|
| GitLab CI ou Jenkins | O código já está no GitHub; Jenkins exige servidor próprio |
| Publicação manual | Não demonstra automação e é sujeita a erro humano |

## Consequências

**Positivas**
- Detecção rápida de erros de tipo e de build.
- Entrega automatizada e reproduzível.
- Evidência direta para a disciplina (pipeline verde).

**Negativas / riscos**
- Tempo de configuração inicial.
- Segredos (chaves do Supabase) precisam ser guardados nos *secrets* do GitHub, nunca no código.

## Evidências

- Arquivo `ci.yml`
- Print do pipeline com todas as etapas verdes
